package com.example.miniweather.Presenter;

public class LocationPresenter  extends BasePresenter{



}
