package com.example.miniweather.View;

public class LocationActivity {
}
